using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class BallController : MonoBehaviour
{
    public float minY = -5.5f;
    public float maxV = 15f;

    Rigidbody2D rb;

    public TextMeshProUGUI scoreText;
    int score = 0;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.y < minY)
        {
            //    transform.position = Vector3.zero;
            GameOver();
        }

        if(rb.velocity.magnitude > maxV)
        {
            rb.velocity = Vector3.ClampMagnitude(rb.velocity, maxV);
        }

        if (score >= 100)
        {
            SceneManager.LoadScene("YouWin");
            score = 0;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Block"))
        {
            Destroy(collision.gameObject);
            score += 10; 
            scoreText.text = score.ToString("000");
        }
    }

    void GameOver()
    {
        SceneManager.LoadScene("GameOver");
    }
}
