using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    float moveHorizontal;
    public float maxX = 7;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        moveHorizontal = Input.GetAxis("Horizontal");
        if ((moveHorizontal > 0 && transform.position.x < maxX) ||
            (moveHorizontal < 0 && transform.position.x > -maxX))
        {
            transform.position += Vector3.right * moveHorizontal * speed * Time.deltaTime;
        }
    }
}
